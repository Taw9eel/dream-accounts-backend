# Dream Accounts Backend

A simple Node.js API to support login and transaction management for Dream Accounts, using MariaDB SkySQL.